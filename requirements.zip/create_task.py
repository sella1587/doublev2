import random
from faker import Faker
from django.utils.timezone import now
from django.core.wsgi import get_wsgi_application
from core.models import (
    ConsolidatedObjects, FacteurChoc, DegreChoc, AvecPlot, AvecCarlingage
)
# Initialisation de Faker
fake = Faker()

# Récupérer des valeurs de référence si elles existent
facteurs_choc = list(FacteurChoc.objects.all())
degres_choc = list(DegreChoc.objects.all())
avec_plots = list(AvecPlot.objects.all())
avec_carlingages = list(AvecCarlingage.objects.all())

# Fonction pour générer des objets factices
def create_fake_consolidated_objects(n=10):
    """Génère et insère n objets ConsolidatedObjects en base de données"""
    
    objects_to_create = []
    
    for _ in range(n):
        obj = ConsolidatedObjects(
            source=random.choice(["PID", "SPEL", "SM3D", "USER"]),
            name=fake.unique.company(),
            component_type=random.choice(["Type A", "Type B", "Type C", None]),
            description=fake.text(max_nb_chars=200),
            trade=fake.job(),
            function=fake.word(),
            lot=fake.random_int(min=1, max=10),
            room=fake.random_element(["Salle A", "Salle B", "Salle C", None]),
            code_client_object=fake.uuid4()[:8],
            code_fournisseur=fake.uuid4()[:8],
            facteur_choc=random.choice(facteurs_choc) if facteurs_choc else None,
            degre_choc=random.choice(degres_choc) if degres_choc else None,
            avec_plots=random.choice(avec_plots) if avec_plots else None,
            avec_carlingage=random.choice(avec_carlingages) if avec_carlingages else None,
            date_traitement_cao=fake.date_time_between(start_date="-1y", end_date="now"),
            creation_date=now(),
            date_last_modified=fake.date_time_between(start_date="-6m", end_date="now"),
            date_last_modified_dc=fake.date_time_between(start_date="-3m", end_date="now"),
            status=random.choice(["A", "B", "C", None])
        )
        objects_to_create.append(obj)

    # Insertion en bulk pour optimiser la performance
    ConsolidatedObjects.objects.bulk_create(objects_to_create)
    # print(f"{n} objets ConsolidatedObjects ont été générés avec succès.")

# Générer 50 objets factices
create_fake_consolidated_objects(n=50)
     