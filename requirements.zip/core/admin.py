from django.contrib import admin
from django_tenants.admin import TenantAdminMixin

from core.models import Ouvrage

@admin.register(Ouvrage)
class ClientAdmin(TenantAdminMixin, admin.ModelAdmin):
    list_display = ('ouvrage', 'schema_name','code_client','is_active')

admin.site.site_title ="Administration Double Codification"
admin.site.index_title = "Admin Double Codification"
