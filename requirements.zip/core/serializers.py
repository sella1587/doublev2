from rest_framework import serializers
from .models import ConsolidatedObjects, ObjectsFromCao

class DynamicConsolidatedObjectsSerializer(serializers.ModelSerializer):
    generate_data_config = serializers.SerializerMethodField()
    def __init__(self, *args, **kwargs):
        fields_to_include = kwargs.pop('fields', None)
        super().__init__(*args, **kwargs)

        if fields_to_include:
            allowed = set(fields_to_include)
            existing = set(self.fields)
            for field in existing - allowed:
                self.fields.pop(field)

    class Meta:
        model = ConsolidatedObjects
        fields = '__all__'
        
    def get_generate_data_config(self, obj):        
        return obj.generate_data_config()  


class SerialObjectFromCao(serializers.ModelSerializer):
    class Meta:
        model = ObjectsFromCao
        fields = []